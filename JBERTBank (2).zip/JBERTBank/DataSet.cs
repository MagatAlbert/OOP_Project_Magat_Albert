﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JBERTBank
{
    class DataSet
    {
        public static List<Clients> ClientList = new List<Clients>();
    }
}
