﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JBERTBank
{
    class Program
    {
        
        public string ClientID;
        static void Main(string[] args)
        {
            Program p = new Program();
            p.initData();
            p.ProgramStart();
        }
        public void ProgramStart()
        {
            ho:
            switch (HomePage())
            {
                case 1:
                    LogIn();
                    break;
                case 2:
                    Program p = new Program();
                    p.Register();
                    break;
                default:
                    Console.Write("Invalid Input, Press any key to continue!!");
                    Console.ReadKey();
                    goto ho;    
            }
        }
        public void exit()
        {
            char exit='m';
            ex:
            
            Console.Write("Do you want to exit? [Y/N(press any key)]");
            try
            {
                 exit = char.Parse(Console.ReadLine());
            }
            catch { invalidInput(); Console.ReadKey(); goto ex; }

            switch (exit)
            {
                case 'y':
                case 'Y':
                    ProgramStart();
                    break;
                case 'n':
                case 'N':
                    Console.Write("OK");
                    break;

            };
        }
        public byte HomePage()
        {
            byte option = 0 ;
            gotohome:
            Console.Clear();
            Console.WriteLine(">>>>>>>>>>>  WELCOME TO JBERT BANK  <<<<<<<<<<<<");

            Console.WriteLine(">>>>>>>>>>>*****Select Option*******<<<<<<<<<<<<");

            Console.WriteLine(">>>>>>>>>>>********1. Login*********<<<<<<<<<<<<");
            Console.WriteLine(">>>>>>>>>>>*******2. Register*******<<<<<<<<<<<<");
            try
            {
                Console.Write(">>>>>>>>>>>*****   Please input choice:");
                 option = byte.Parse(Console.ReadLine());
                
            }
            catch { invalidInput(); Console.ReadKey(); goto gotohome; }
            return option;
        }
        public void Register()
        {
            Console.Clear();
            String firstname, lastname, middlename, address, username, password;
            byte age;
            Console.WriteLine(">>>>>>>*****Registration Form*******<<<<<<<");
            Console.Write("Please Input First Name:");
            firstname = Console.ReadLine();
            Console.Write("Please Input Last Name:");
            lastname = Console.ReadLine();
            Console.Write("Please Input Middle Name:");
            middlename = Console.ReadLine();
            Console.Write("Please Input Address:");
            address = Console.ReadLine();
        age:
            try
            {
                Console.Write("Please Input age:");
                 age = byte.Parse(Console.ReadLine());
            }
            catch
            {
                invalidInput();
                goto age;
            }
            Console.Write("Please Input username:");
            username = Console.ReadLine();
            Console.Write("Please Input password:");
            password = Console.ReadLine();
        dep:
            double balance;
            try
            {
                Console.Write("Input your First Deposit :");
                 balance = double.Parse(Console.ReadLine());
            }
            catch { invalidInput(); goto dep; }
            if (balance <= 0)
            {
                invalidInput();
                goto dep;
            }
            else
            {
                string myId = Guid.NewGuid().ToString();
                Clients newClient = new Clients(myId, firstname, lastname, middlename, 
                    address, age, username, password, balance);
                DataSet.ClientList.Add(newClient);
                adlibMessage("Registered");
                ProgramStart();
            }
            
        }
        public void adlibMessage(string process)
        {
            Console.Write("jjjjjjjjjjjjjj<<<<<<<<-_->>>>>>>>lllllllllllll\n");
            Console.Write("XXXXXXX   "+process+" Successfully    XXXXXXXXXXXX\n");
            Console.Write("jjjjjjjjjjjjjj<<<<<<<<-_->>>>>>>>lllllllllllll\n\n");
            Console.Write("         PRESS ANY KEY TO CONTINUE");
            Console.ReadKey();
            Console.Clear();
            

        }
        public void invalidInput()
        {
            Console.Write("\t\tInvalid Input!!!\n\n");
        }
        public void LogIn()
        {
            uncorrect:
            Console.Clear();
            String username, password;
            Console.WriteLine(">>>>>>>>*****LOGIN*****<<<<<<<<<");
            Console.Write("Please Input Username:");
            username = Console.ReadLine();
            Console.Write("Please Input Password:");
   
            password = null;

            while (true)
            {
                var key = System.Console.ReadKey(true);
                if (key.Key == ConsoleKey.Enter)
                    break;
                password += key.KeyChar;
                System.Console.Write("*");

            }
        uncorrec:
            try
            {
                Clients respond = DataSet.ClientList.Find(r => (r.Username == username) && 
                    (r.Password == password));
                ClientID = respond.Id;
                
                loggedIn();Console.ReadKey();
            }
            catch { Console.Write("Access Denied"); Console.ReadKey(); exit(); goto uncorrec; }
        }
        public void loggedIn()
        {
            
            
            Clients respond = DataSet.ClientList.Find(r =>(r.Id == ClientID));
        invalid:
            UPDATEDELETE d = new UPDATEDELETE();
            Console.Clear();
            Console.Write("jjjjjjjjjjjjjj<<<<<<<<-_->>>>>>>>lllllllllllll\n");
            Console.Write("           WELCOME "+respond.FirstName+" TO JBERT BANK    \n\n");
            Console.Write("              Select Option\n");
            Console.Write("\t\t(1) Check Balance\n\t\t(2) Withdraw \n\t\t(3) Deposit \n\t\t(4) Delete this Account(think twice before you select)\n\t\t(5) Log Out\n");
            Console.Write("jjjjjjjjjjjjjj<<<<<<<<-_->>>>>>>>lllllllllllll\n\t\t");
            byte choice;
            try
            {
                choice = byte.Parse(Console.ReadLine());
            }catch{Console.Write("Invalid input");goto invalid;}
            switch(choice)
            {
                case 1:
                    checkBalance();
                    break;
                case 2:
                    withdraw();
                    break;
                case 3:
                    deposit();
                    break;
                case 4:
                    deleteAcount();
                    break;
                case 5:
                    LogOut();
                    break;
                case 6:
                    d.UPDATE();
                    break;
                case 7:
                    d.Delete();
                    break;
            }
        }
        public void checkBalance()
        {
            Console.Clear();
            Clients respond = DataSet.ClientList.Find(r => (r.Id == ClientID));
            Console.Write("jjjjjjjjjjjjjj<<<<<<<<-_->>>>>>>>lllllllllllll\n");
            Console.Write("\n\tYour Current Balance:"+ respond.Balance+"\n\n");
            Console.Write("        PRESS ANY KEY TO CONTINUE!!!\n");
            Console.Write("jjjjjjjjjjjjjj<<<<<<<<-_->>>>>>>>lllllllllllll\n");
            Console.ReadKey();
            loggedIn();

        }
        public void withdraw()
        {
            Console.Clear();
            Clients respond = DataSet.ClientList.Find(r => (r.Id == ClientID));
            Console.Write("jjjjjjjjjjjjjj<<<<<<<<-_->>>>>>>>lllllllllllll\n");
            Console.Write("       Your Current Balance is:"+respond.Balance.ToString("F")+"\n");
            withdraw:
            Console.Write("       Input you wish to withdraw:");
            double with = 0.0;
            try
            {
                with = double.Parse(Console.ReadLine());
            }
            catch { invalidInput(); goto withdraw; }
            if (with > respond.Balance)
            {
                Console.Write("You inputted Greater amount than your current Balance\n\n"); goto withdraw;
            }
            else if (with < respond.Balance && with >= 0)
            {
                respond.Balance -= with; 
                Console.Write("\n\n\t\t Withdraw Account:" + with + "\n\n");
                Console.Write("\n\n\t\t Current Balance:"+ respond.Balance.ToString("F")+"\n\n");
                adlibMessage("Withdrawed ");
                loggedIn();
            }
            else
            {
                invalidInput(); goto withdraw; 
            }
        }
        public void deposit()
        {
            Console.Clear();
            Clients respond = DataSet.ClientList.Find(b => (b.Id == ClientID));
            Console.Write("jjjjjjjjjjjjjj<<<<<<<<-_->>>>>>>>lllllllllllll\n");
            Console.WriteLine("       Your Current Balance is:" + respond.Balance.ToString("F") + "\n\n");
            dep:
            Console.Write("       Input your Deposit:");
            double deposit;
            try
            {
                deposit = double.Parse(Console.ReadLine());
            }
            catch { invalidInput(); goto dep; }
            if (deposit <= 0)
            {
                invalidInput();
                goto dep;
            }
            else
            {
                respond.Balance += deposit;
                
                Console.Write("\n");
                adlibMessage("Deposited ");
                loggedIn();
            }
        }
        public void LogOut()
        {
            Console.Clear();
            ClientID = null;
            Console.Write("jjjjjjjjjjjjjj<<<<<<<<-_->>>>>>>>lllllllllllll\n");
            Console.Write("\tTHANK YOU FOR CHOOSING JBERT BANK    \n\n");
            Console.Write("jjjjjjjjjjjjjj<<<<<<<<-_->>>>>>>>lllllllllllll\n");
            Console.ReadKey();
            ProgramStart();
        }
        public void initData()
        {
            String firstname, lastname, middlename, address, username, password;
            double balance;
            byte age;
            Clients defaultClient = new Clients(Guid.NewGuid().ToString(),
                firstname = "JL",
                lastname = "MA",
                middlename = "GG",
                address = "US",
                age = 25,
                username = "jl55",
                password = "waiforever",
                balance = 100000
                );
            DataSet.ClientList.Add(defaultClient);

        }
        public void deleteAcount()
        {
            double balance;
            Clients respond = DataSet.ClientList.Find(r => (r.Id == ClientID));
            Console.Clear();
            respond.Address = "";
            respond.Age = 0;
            respond.Balance = 0.0;
            respond.LastName = "";
            respond.MiddleName = "";
            respond.Password = Guid.NewGuid().ToString();
            respond.Username = Guid.NewGuid().ToString();
            respond.Id = "";
            Console.Write(respond.Id);
            Console.ReadKey();
            ClientID = null;
            adlibMessage("Deleted");
            Console.Write("jjjjjjjjjjjjjj<<<<<<<<-_->>>>>>>>lllllllllllll\n");
            Console.Write("\n\t\tTHANK YOU FOR CHOOSING JBERT BANK\n");
            Console.Write("jjjjjjjjjjjjjj<<<<<<<<-_->>>>>>>>lllllllllllll\n\n");                        
            ProgramStart();
        }
    }
}
