﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JBERTBank
{
    class Clients
    {
        Program p = new Program();
        public String FirstName, LastName, MiddleName, Address, Username, Password, Id;
        public byte Age;
        public double Balance;

        public Clients(String id, String firstname, String lastname, String middlename, String address, byte age, String username, String password, double balance)
        {
            this.FirstName = firstname;
            this.LastName = lastname;
            this.MiddleName = middlename;
            this.Address = address;
            this.Username = username;
            this.Password = password;
            this.Age = age;
            this.Id = id;
            this.Balance = balance;
        }
        public String toString()
        {
            return "User{" +
                  ", Id='" + Id + '\'' +
                    "FirstName='" + FirstName + '\'' +
                    ", LastName='" + LastName + '\'' +
                    ", MiddleName='" + MiddleName + '\'' +
                    ", Address='" + Address + '\'' +
                     ", Age=" + Age +
                    ", Username='" + Username + '\'' +
                    ", Password='" + Password + '\'' +
                    ", Balance='" + Balance + '\'' +
                    '}';
        }
        public Clients(String id, String firstName, String lastName)
        {
            FirstName = firstName;
            LastName = lastName;
            Id = id;
        }
    }
}
